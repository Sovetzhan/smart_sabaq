import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';

import 'firebase_options.dart';
import 'screens/teachers/teachers_screen.dart';

import 'services/lesson_plan_service.dart';

import 'core/current_user.dart';
import 'core/user_context.dart';
import 'core/user_role.dart';

Future<void> testGetLessonPlan() async {
  final result = await LessonPlanService().getByScheduleAndDate(
    schoolId: 'school-uuid-1',
    scheduleItemId: 'schedule-item-uuid-1',
    lessonDate: DateTime(2026, 2, 4),
  );

  if (result == null) {
    debugPrint('LESSON PLAN NOT FOUND');
  } else {
    debugPrint('LESSON PLAN FOUND: ${result.topic}');
  }
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  // ⚠️ ВРЕМЕННО. ПОТОМ БУДЕТ ИЗ АВТОРИЗАЦИИ
  CurrentUser.user = UserContext(
    userId: 'teacher-uuid-1',
    schoolId: 'school-uuid-1',
    role: UserRole.admin, // admin / teacher
  );

  // ТЕСТ. МОЖНО ВКЛЮЧАТЬ И ВЫКЛЮЧАТЬ
  // await testGetLessonPlan();

  runApp(const AdminApp());
}

class AdminApp extends StatelessWidget {
  const AdminApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'School Admin',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.blueGrey,
      ),
      home: TeachersScreen(),
    );
  }
}
