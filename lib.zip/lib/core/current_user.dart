import 'user_context.dart';
import 'user_role.dart';

class CurrentUser {
  static UserContext? user;
}
