class FirestoreCollections {
  static const schools = 'schools';
  static const classes = 'classes';
  static const teachers = 'teachers';
  static const subjects = 'subjects';
  static const timeSlots = 'time_slots';
  static const scheduleItems = 'schedule_items';
  static const lessonPlans = 'lesson_plans';
}

